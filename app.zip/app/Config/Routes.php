<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/', 'databatako::index');
$routes->get('/DataBatako/index', 'DataBatako::index');
