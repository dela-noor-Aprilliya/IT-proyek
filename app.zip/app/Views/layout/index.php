<?php 
 echo view('/layout/header');
 echo view('/layout/navbar');
 echo view('/layout/topbar');
 echo view('/layout/content');
 echo view('/layout/footer');
